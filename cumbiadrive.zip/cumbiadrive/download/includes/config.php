<?php 
/**
 * ====================================================================================
 *                           Premium URL Shortener (c) KBRmedia
 * ----------------------------------------------------------------------------------
 * @copyright This software is exclusively sold at CodeCanyon.net. If you have downloaded this
 *  from another site or received it from someone else than me, then you are engaged
 *  in an illegal activity. You must delete this software immediately or buy a proper
 *  license from http://codecanyon.net/user/KBRmedia/portfolio?ref=KBRmedia.
 *
 *  Thank you for your cooperation and don't hesitate to contact me if anything :)
 * ====================================================================================
 *
 * @author KBRmedia (http://gempixel.com)
 * @link http://gempixel.com 
 * @license http://gempixel.com/license
 * @package Premium URL Shortener
 * @subpackage Configuration File
 */
// Database Configuration
  $dbinfo= array (
    "host" => 'localhost',        // Your mySQL Host (usually Localhost)
    "db" => 'dcdrv',            // The database where you have dumped the included sql file
    "user" => 'dcdrv_user',        // Your mySQL username
    "password" => 'AlexChance@2013',    //  Your mySQL Password 
    "prefix" => 'down_'      // Prefix for your tables e.g. short_ if you are using same db for multiple scripts
  );

  $config = array(
    // Timezone - List of available timezones (Pick the closest): https://php.net/manual/en/timezones.php
    "timezone" => "America/Argentina/Buenos_Aires",
    // Cache Data - If you notice anomalies, disable this. You should enable this you get high hits
    "cache" => FALSE,
    // Use CDN to host libraries for faster loading
    "cdn" => TRUE,
    // Enable Compression? Makes your website faster
    "gzip" => TRUE,
    /*
     ====================================================================================
     *  Security Key & Token - Please don't change this if your site is live.
     * ----------------------------------------------------------------------------------
     *  - Setup a security phrase - This is used to encode some important user 
     *    information such as password. The longer the key the more secure they are.
     *
     *  - If you change this, many things such as user login and even admin login will 
     *    fail.
     *
     *  - If the two config below don't have any values or have 1500Watts or 825945c6d363b07d0a4110a6035d36ca replace these by a random key.
     ====================================================================================
    */
    "security" => '1500Watts',  // !!!! DON'T CHANGE THIS IF YOUR SITE IS LIVE
    "public_token" => '825945c6d363b07d0a4110a6035d36ca', // Please don't change this, this is randomly generated

    "debug" => 0,   // Enable debug more (outputs errors) - 0 = OFF, 1 = Error message, 2 = Error + Queries (Don't enable this if your site is live!)
    "demo" => 0 // Demo mode
  );

//Note: The following fields should be filled as follows e.g. define('ga_email','test@gmail.com')
define('ga_email','');  // Your google analytics email
define('ga_password','');  // Your google analytics password
define('ga_profile_id','');  // Your google analytics profile id (now known as view ID) not account id (See documentation)
define('folder','');  // If you installed this script in a folder, you add the path of the folder here e.g. /short

// Include core.php
include ('core.php');
?>