<?php defined("APP") or die() ?>
<section>
  <div class="container">
  	<div class="centered is404">
			<?php echo $content ?>
  	</div>
  </div>
</section>